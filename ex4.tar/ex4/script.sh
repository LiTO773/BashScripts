#!/bin/bash
# Verificar se existe um parametro
if [ $# -eq 0 ]
then
  echo "É necessário um parametro!"
  exit 1
fi

cd surfreport

for praia in $(ls)
do
  cd $praia
  touch ../../$(echo $praia)_$1.csv
  for mes in $(ls)
  do
    cd $mes
    for ficheiro in $(ls)
    do
      data="$(echo $ficheiro | cut -d "." -f1)"
      valor="$(cat $ficheiro | grep "$1:" | cut -d ":" -f2)"
      echo "$data;$valor" >> ../../../$(echo $praia)_$1.csv
    done
    cd ..
  done
  cd ..
done